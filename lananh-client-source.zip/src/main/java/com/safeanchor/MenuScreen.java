package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Màn hình cài đặt cuộn được: vuốt lên/xuống hoặc lăn chuột. Nút chỉ kích hoạt khi chạm nhả (không bấm nhầm lúc vuốt). */
public class MenuScreen extends Screen {
    static final Identifier BG = Identifier.of("safeanchor", "textures/gui/bg.png");
    final Screen parent;
    final List<Supplier<ClickableWidget>> makers;
    final List<ClickableWidget> ws = new ArrayList<>();
    double scroll, px, py;
    boolean pend, drag;
    ButtonWidget back;
    Runnable swipeL, swipeR;
    double dxTot, dyTot;

    public MenuScreen(String title, Screen parent, List<Supplier<ClickableWidget>> makers) {
        super(Text.literal(title));
        this.parent = parent; this.makers = makers;
    }

    int top() { return 56; }
    int bottom() { return height - 30; }

    @Override protected void init() {
        ws.clear(); clearChildren();
        for (var m : makers) { ClickableWidget w = m.get(); ws.add(w); addSelectableChild(w); }
        back = ButtonWidget.builder(Text.literal("Quay lại"), b -> close()).dimensions(width / 2 - 60, height - 26, 120, 20).build();
        addDrawableChild(back);
        layout();
    }

    void layout() {
        double max = Math.max(0, ws.size() * 24 - (bottom() - top()));
        scroll = Math.max(0, Math.min(max, scroll));
        for (int i = 0; i < ws.size(); i++) { ws.get(i).setX(width / 2 - 110); ws.get(i).setY((int) (top() + i * 24 - scroll)); }
    }

    @Override public void close() { MinecraftClient.getInstance().setScreen(parent); }
    @Override public void removed() { Config.save(); MinecraftClient.getInstance().options.write(); }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float d) {
        var mc = MinecraftClient.getInstance();
        if (mc.getResourceManager().getResource(BG).isPresent())
            ctx.drawTexture(RenderLayer::getGuiTextured, BG, 0, 0, 0f, 0f, width, height, 512, 512, 512, 512);
        else {
            ctx.fill(0, 0, width, height, 0xE00B0B14);
            int l = width / 2 - 125, r = width / 2 + 125;
            ctx.fill(l, 0, r, height, 0xF0161624);
            ctx.fill(l, 0, l + 1, height, 0xFF8B5CF6);
            ctx.fill(r - 1, 0, r, height, 0xFF8B5CF6);
            ctx.fill(l, 30, r, 31, 0xFF8B5CF6);
        }
    }

    @Override public void render(DrawContext ctx, int mx, int my, float d) {
        super.render(ctx, mx, my, d);
        Anim.title(ctx, width / 2, 8);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 36, 0xFFFFFFFF);
        ctx.enableScissor(0, top(), width, bottom());
        for (ClickableWidget w : ws) if (w.getY() + 20 > top() && w.getY() < bottom()) w.render(ctx, mx, my, d);
        ctx.disableScissor();
    }
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    boolean inList(double x, double y) { return y >= top() && y <= bottom(); }

    @Override public boolean mouseClicked(double x, double y, int b) {
        if (!inList(x, y)) return back != null && back.mouseClicked(x, y, b);
        if (inList(x, y)) {
            for (ClickableWidget w : ws) if (w.isMouseOver(x, y)) {
                if (w instanceof SliderWidget) return super.mouseClicked(x, y, b);
                break;
            }
            pend = true; drag = false; px = x; py = y; dxTot = 0; dyTot = 0; return true;
        }
        return super.mouseClicked(x, y, b);
    }
    @Override public boolean mouseDragged(double x, double y, int b, double dx, double dy) {
        if (pend) { dxTot += dx; dyTot += dy; if (Math.abs(y - py) > 4 || Math.abs(x - px) > 12) drag = true; if (Math.abs(y - py) > 4) { scroll -= dy; layout(); } return true; }
        return super.mouseDragged(x, y, b, dx, dy);
    }
    @Override public boolean mouseReleased(double x, double y, int b) {
        if (pend) {
            pend = false;
            if (Math.abs(dxTot) > 60 && Math.abs(dxTot) > Math.abs(dyTot) * 1.5 && (swipeL != null || swipeR != null)) {
                drag = false;
                if (dxTot < 0 && swipeL != null) swipeL.run(); else if (dxTot > 0 && swipeR != null) swipeR.run();
                return true;
            }
            if (!drag) { super.mouseClicked(px, py, b); }
            drag = false;
            return super.mouseReleased(x, y, b);
        }
        return super.mouseReleased(x, y, b);
    }
    @Override public boolean mouseScrolled(double x, double y, double h, double v) { scroll -= v * 20; layout(); return true; }
}
