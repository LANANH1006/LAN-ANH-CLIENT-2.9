package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.block.Blocks;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

/** Macro Crystal: cầm crystal + giữ chuột phải vào obsidian -> game tự đặt, client tự đập nổ crystal vừa đặt. */
public class CrystalMacro {
    static int cd, ttl;
    static BlockPos base;

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (!c.crystalMacro || !c.enabled || p == null || w == null || mc.interactionManager == null || mc.currentScreen != null) { ttl = 0; return; }
        if (cd > 0) cd--;
        if (!p.getMainHandStack().isOf(Items.END_CRYSTAL) || !mc.options.useKey.isPressed()) { ttl = 0; return; }

        // nhớ obsidian/bedrock đang ngắm (sau khi đặt, tâm sẽ chuyển sang crystal nên cần nhớ lại)
        if (mc.crosshairTarget instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK) {
            var st = w.getBlockState(bh.getBlockPos());
            if (st.isOf(Blocks.OBSIDIAN) || st.isOf(Blocks.BEDROCK)) { base = bh.getBlockPos(); ttl = 12; }
        } else if (ttl > 0) ttl--;
        if (ttl <= 0 || base == null || cd > 0) return;

        EndCrystalEntity best = null; double bd = 1e9;
        for (EndCrystalEntity e : w.getEntitiesByClass(EndCrystalEntity.class, new Box(base.up()).expand(0.6), x -> true)) {
            double d = Util.distToBox(p.getEyePos(), e.getBoundingBox());
            if (d > Math.max(3.0, c.reach)) continue;
            if (Util.selfDamage(p, e.getPos()) >= p.getHealth() + p.getAbsorptionAmount()) continue;   // không tự sát
            if (d < bd) { bd = d; best = e; }
        }
        if (best != null) {
            mc.interactionManager.attackEntity(p, best);
            p.swingHand(Hand.MAIN_HAND);
            cd = Math.max(0, c.macroDelay);
        }
    }
}
