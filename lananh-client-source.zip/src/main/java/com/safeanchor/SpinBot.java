package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;

/** Spin Bot: gửi góc nhìn xoay tròn lên server (người khác thấy nhân vật xoay), camera của bạn đứng yên. */
public class SpinBot {
    static float yaw, phase;
    static boolean was;

    static void restore(MinecraftClient mc) {
        var p = mc.player;
        if (p != null && p.networkHandler != null) Util.sendLook(p.getYaw(), p.getPitch());
        was = false;
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (!c.spinOn || !c.enabled || p == null || mc.world == null || p.networkHandler == null) { if (was) restore(mc); return; }
        // bay elytra / đang dùng đồ (cung, ăn) cần hướng thật -> tạm nghỉ
        if (p.isGliding() || (c.spinPause && p.isUsingItem())) { if (was) restore(mc); return; }
        if (!was) { yaw = p.getYaw(); phase = 0; }
        yaw = MathHelper.wrapDegrees(yaw + (c.spinDir == 0 ? 1 : -1) * (float) c.spinSpeed);
        phase += 0.35f;
        float pitch = switch (c.spinPitch) {
            case 1 -> 90f;
            case 2 -> 60f * (float) Math.sin(phase);
            default -> p.getPitch();
        };
        Util.sendLook(yaw, pitch);
        was = true;
    }
}
