package com.safeanchor;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Safe Anchor: 1 click đặt anchor -> đặt ĐÚNG 1 obsidian chắn -> nạp glowstone -> nổ.
 * Chỉ chạy khi chính bạn đặt anchor bằng tay (không chạy khi client tự đặt, tránh đặt trùng).
 */
public class AutoAnchor {
    static BlockPos anchor; static int phase, wait, fail, quiet, shieldTry;
    static BlockPos shield; static boolean shieldDone;

    public static boolean busy() { return anchor != null; }

    public static void toggle(MinecraftClient mc) {
        Config.I.anchor = !Config.I.anchor; Config.save();
        Util.msg("Safe Anchor: " + (Config.I.anchor ? "§aBẬT" : "§cTẮT"));
    }

    public static void onPlace(BlockHitResult hit) {
        if (!Config.I.anchor || !Config.I.enabled || Util.bot) return;
        if (anchor != null || quiet > 0 || AnchorCombo.stage != 0) return;
        var w = MinecraftClient.getInstance().world;
        if (w == null || w.getBlockState(hit.getBlockPos()).isOf(Blocks.RESPAWN_ANCHOR)) return;     // bấm vào anchor có sẵn = nạp tay, bỏ qua
        BlockPos pos = w.getBlockState(hit.getBlockPos()).isReplaceable() ? hit.getBlockPos() : hit.getBlockPos().offset(hit.getSide());
        begin(pos);
    }

    static void begin(BlockPos pos) { anchor = pos; phase = 0; wait = 2; fail = 0; shieldTry = 0; shield = null; shieldDone = false; }

    static void reset() { anchor = null; phase = 0; quiet = 12; shield = null; }

    /** Phím: tự đặt anchor ngay chỗ đối thủ gần nhất rồi nạp + nổ. */
    public static void bomb(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (p == null || w == null || anchor != null) return;
        PlayerEntity t = Util.nearestEnemy(8);
        if (t == null) { Util.warn("Không có đối thủ gần!"); return; }
        if (!Util.has(s -> s.isOf(Items.RESPAWN_ANCHOR))) { Util.warn("Không có anchor!"); return; }
        BlockPos tp = t.getBlockPos(), pick = null; double bd = 1e9;
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) for (int dy = 0; dy <= 1; dy++) {
            BlockPos q = tp.add(dx, dy, dz);
            if (!w.getBlockState(q).isReplaceable()) continue;
            if (p.getEyePos().distanceTo(Vec3d.ofCenter(q)) > c.reach) continue;
            if (!w.getOtherEntities(null, new Box(q)).isEmpty()) continue;
            double d = Vec3d.ofCenter(q).distanceTo(t.getPos());
            if (d < bd) { bd = d; pick = q; }
        }
        if (pick == null) { Util.warn("Không có chỗ đặt anchor cạnh đối thủ!"); return; }
        if (Util.placeBlock(pick, Items.RESPAWN_ANCHOR)) begin(pick);
    }

    /** Ô obsidian chắn: nằm giữa anchor và người chơi (đứng ngay trên anchor thì chắn phía trên). */
    static BlockPos shieldPos(net.minecraft.client.network.ClientPlayerEntity p) {
        double dx = p.getX() - (anchor.getX() + 0.5), dz = p.getZ() - (anchor.getZ() + 0.5);
        double dy = p.getEyeY() - (anchor.getY() + 0.5);
        if (Math.hypot(dx, dz) < 0.9 && dy > 0.5) return anchor.up();
        return anchor.offset(Direction.getFacing(dx, 0, dz));
    }

    static int explodeSlot(net.minecraft.client.network.ClientPlayerEntity p) {
        int pref = Config.I.totemSlot - 1;
        var inv = p.getInventory();
        for (int k = 0; k < 9; k++) {
            int i = (pref + k + 9) % 9;
            ItemStack s = inv.getStack(i);
            if (!s.isOf(Items.GLOWSTONE) && !s.isOf(Items.RESPAWN_ANCHOR)) return i;
        }
        return pref;
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (quiet > 0) quiet--;
        if (anchor == null || !c.anchor || p == null || w == null) return;
        if (wait > 0) { wait--; return; }
        if (!w.getBlockState(anchor).isOf(Blocks.RESPAWN_ANCHOR)) { if (++fail > 20) reset(); return; }
        if (p.getEyePos().distanceTo(Vec3d.ofCenter(anchor)) > c.reach + 1) { reset(); return; }

        switch (phase) {
            case 0 -> {   // đúng 1 block obsidian chắn
                if (!c.anchorSafe || shieldDone || !Util.has(s -> s.isOf(Items.OBSIDIAN))) { phase = 1; wait = 1; return; }
                if (shield == null) shield = shieldPos(p);
                if (!w.getBlockState(shield).isReplaceable()) { shieldDone = true; phase = 1; wait = 1; return; }   // đã có block chắn sẵn
                if (p.getBoundingBox().intersects(new Box(shield))) { shieldDone = true; phase = 1; wait = 1; return; } // đứng ngay ô đó, bỏ
                if (Util.placeBlock(shield, Items.OBSIDIAN)) { shieldDone = true; phase = 1; wait = 1; return; }
                if (++shieldTry >= 3) { shieldDone = true; phase = 1; wait = 1; return; }                         // thử 3 lần không được thì bỏ, không đặt thêm
                wait = 1;
            }
            case 1 -> {   // nạp glowstone
                int ch = w.getBlockState(anchor).get(Properties.CHARGES);
                if (ch < 1) {
                    if (!Util.selectItem(s -> s.isOf(Items.GLOWSTONE))) { Util.warn("Không có glowstone!"); reset(); return; }
                    Util.useOnBlock(anchor, Direction.UP);
                }
                phase = 2; wait = 1;
            }
            case 2 -> {   // nổ
                if (w.getBlockState(anchor).get(Properties.CHARGES) < 1) { if (++fail > 10) reset(); wait = 1; return; }
                Util.select(explodeSlot(p));
                Util.useOnBlock(anchor, Direction.UP);
                reset();
            }
            default -> reset();
        }
    }
}
